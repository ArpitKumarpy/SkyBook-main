import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Armchair,
  CalendarClock,
  CreditCard,
  LogOut,
  Plane,
  Search,
  Shield,
  Ticket,
  User,
  Users,
} from "lucide-react";
import { api } from "./lib/api";
import "./styles.css";

const emptyFlight = {
  flightNumber: "",
  airlineName: "",
  source: "",
  destination: "",
  price: "",
  status: "SCHEDULED",
  aircraftId: "",
};

const emptyAircraft = { modelNo: "", totalSeats: "" };
const emptySchedule = { departureDate: "", departureTime: "", arrivalTime: "", flightId: "" };
const emptySeat = { seatNumber: "", seatClass: "ECONOMY", seatType: "WINDOW", aircraftId: "" };

const roleTabs = {
  USER: ["search", "bookings", "passengers", "payments", "tickets"],
  ADMIN: ["dashboard", "flights", "aircraft", "schedules", "seats", "users", "bookings", "tickets"],
};

function App() {
  const [session, setSession] = useState(() => {
    const raw = localStorage.getItem("skybook.session");
    return raw ? JSON.parse(raw) : null;
  });
  const [active, setActive] = useState(session?.role === "ADMIN" ? "dashboard" : "search");

  useEffect(() => {
    if (session) localStorage.setItem("skybook.session", JSON.stringify(session));
    else localStorage.removeItem("skybook.session");
  }, [session]);

  const signOut = () => {
    setSession(null);
    setActive("search");
  };

  if (!session) return <AuthScreen onAuth={setSession} />;

  const tabs = roleTabs[session.role] || roleTabs.USER;

  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <Plane size={26} />
          <div>
            <strong>SkyBook</strong>
            <span>{session.role === "ADMIN" ? "Admin console" : "Booking desk"}</span>
          </div>
        </div>
        <nav>
          {tabs.map((tab) => (
            <button
              key={tab}
              className={active === tab ? "nav-item active" : "nav-item"}
              onClick={() => setActive(tab)}
              title={labelFor(tab)}
            >
              {iconFor(tab)}
              <span>{labelFor(tab)}</span>
            </button>
          ))}
        </nav>
        <div className="account">
          <div className="avatar">{session.email.slice(0, 1).toUpperCase()}</div>
          <div>
            <strong>{session.email}</strong>
            <span>{session.role}</span>
          </div>
          <button className="icon-button" onClick={signOut} title="Sign out">
            <LogOut size={18} />
          </button>
        </div>
      </aside>
      <main className="workspace">
        {active === "dashboard" && <AdminDashboard session={session} />}
        {active === "search" && <FlightSearch session={session} />}
        {active === "flights" && <CrudPanel title="Flights" resource="flights" empty={emptyFlight} fields={flightFields} idKey="id" session={session} />}
        {active === "aircraft" && <CrudPanel title="Aircraft" resource="aircrafts" empty={emptyAircraft} fields={aircraftFields} idKey="id" session={session} />}
        {active === "schedules" && <CrudPanel title="Schedules" resource="schedules" empty={emptySchedule} fields={scheduleFields} idKey="id" session={session} />}
        {active === "seats" && <CrudPanel title="Seats" resource="seats" empty={emptySeat} fields={seatFields} idKey="id" session={session} />}
        {active === "users" && <CrudPanel title="Users" resource="users" empty={emptyUser} fields={userFields} idKey="id" session={session} />}
        {active === "bookings" && <Bookings session={session} />}
        {active === "passengers" && <Passengers session={session} />}
        {active === "payments" && <Payments session={session} />}
        {active === "tickets" && <Tickets session={session} />}
      </main>
    </div>
  );
}

function AuthScreen({ onAuth }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    password: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const payload = mode === "login" ? pick(form, ["email", "password"]) : form;
      const data = await api.publicPost(`/auth/${mode}`, payload);
      onAuth({ ...data, role: data.role?.replace("ROLE_", "") });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <main className="auth-page">
      <section className="auth-panel">
        <div className="auth-copy">
          <div className="brand wide">
            <Plane size={30} />
            <div>
              <strong>SkyBook</strong>
              <span>Flight booking system</span>
            </div>
          </div>
          <h1>Operate flights, schedules, seats, bookings, and tickets from one role-aware console.</h1>
          <div className="role-strip">
            <span><Shield size={16} /> Admin CRUD</span>
            <span><User size={16} /> User bookings</span>
          </div>
        </div>
        <form className="login-card" onSubmit={submit}>
          <div className="segmented">
            <button type="button" className={mode === "login" ? "selected" : ""} onClick={() => setMode("login")}>Login</button>
            <button type="button" className={mode === "register" ? "selected" : ""} onClick={() => setMode("register")}>Register</button>
          </div>
          {mode === "register" && (
            <div className="grid two">
              <Field label="First name" value={form.firstName} onChange={(firstName) => setForm({ ...form, firstName })} />
              <Field label="Last name" value={form.lastName} onChange={(lastName) => setForm({ ...form, lastName })} />
              <Field label="Phone number" value={form.phoneNumber} onChange={(phoneNumber) => setForm({ ...form, phoneNumber })} />
            </div>
          )}
          <Field label="Email" type="email" value={form.email} onChange={(email) => setForm({ ...form, email })} />
          <Field label="Password" type="password" value={form.password} onChange={(password) => setForm({ ...form, password })} />
          {error && <div className="error">{error}</div>}
          <button className="primary" disabled={busy}>{busy ? "Please wait..." : mode === "login" ? "Login" : "Create account"}</button>
        </form>
      </section>
    </main>
  );
}

function AdminDashboard({ session }) {
  const [stats, setStats] = useState([]);
  useEffect(() => {
    Promise.all(["flights", "aircrafts", "schedules", "seats", "bookings", "tickets"].map((r) => api.get(`/${r}`, session)))
      .then((data) => setStats(data.map((items, index) => ({ name: ["Flights", "Aircraft", "Schedules", "Seats", "Bookings", "Tickets"][index], count: rowsOf(items).length }))))
      .catch(() => setStats([]));
  }, [session]);
  return (
    <section>
      <Header title="Operations Dashboard" subtitle="Live counts from the Spring Boot API." />
      <div className="metric-grid">
        {stats.map((item) => (
          <article className="metric" key={item.name}>
            <span>{item.name}</span>
            <strong>{item.count}</strong>
          </article>
        ))}
      </div>
    </section>
  );
}

function FlightSearch({ session }) {
  const [query, setQuery] = useState({ source: "", destination: "", departureDate: "" });
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");

  const search = async (event) => {
    event.preventDefault();
    setError("");
    const qs = new URLSearchParams(clean(query)).toString();
    try {
      setResults(await api.get(`/flights/search?${qs}`, session));
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <Header title="Find Flights" subtitle="Search public flight availability and create bookings as a user." />
      <form className="toolbar" onSubmit={search}>
        <Field label="Source" value={query.source} onChange={(source) => setQuery({ ...query, source })} />
        <Field label="Destination" value={query.destination} onChange={(destination) => setQuery({ ...query, destination })} />
        <Field label="Departure date" type="date" value={query.departureDate} onChange={(departureDate) => setQuery({ ...query, departureDate })} />
        <button className="primary icon-text"><Search size={18} />Search</button>
      </form>
      {error && <div className="error">{error}</div>}
      <DataTable rows={results} />
    </section>
  );
}

function CrudPanel({ title, resource, empty, fields, idKey, session }) {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState("");

  const load = async () => {
    setError("");
    try {
      setRows(rowsOf(await api.get(`/${resource}`, session)));
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
  }, [resource]);

  const save = async (event) => {
    event.preventDefault();
    setError("");
    try {
      const payload = normalizePayload(form, fields);
      if (editing) await api.put(`/${resource}/${editing}`, payload, session);
      else await api.post(`/${resource}`, payload, session);
      setForm(empty);
      setEditing(null);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const edit = (row) => {
    setEditing(row[idKey]);
    setForm(Object.fromEntries(Object.keys(empty).map((key) => [key, row[key] ?? ""])));
  };

  const remove = async (row) => {
    setError("");
    try {
      await api.delete(`/${resource}/${row[idKey]}`, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <Header title={title} subtitle="Create, update, and remove records available to admins." />
      <form className="editor" onSubmit={save}>
        {fields.map((field) => (
          <Field key={field.name} {...field} value={form[field.name] ?? ""} onChange={(value) => setForm({ ...form, [field.name]: value })} />
        ))}
        <div className="form-actions">
          <button className="primary">{editing ? "Update" : "Create"}</button>
          {editing && <button type="button" className="secondary" onClick={() => { setEditing(null); setForm(empty); }}>Cancel</button>}
        </div>
      </form>
      {error && <div className="error">{error}</div>}
      <DataTable rows={rows} onEdit={edit} onDelete={remove} />
    </section>
  );
}

function Bookings({ session }) {
  const [form, setForm] = useState({ userId: session.userId || "", scheduleId: "", seatId: "" });
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");

  const load = async () => setRows(rowsOf(await api.get("/bookings", session)));
  useEffect(() => { load().catch((err) => setError(err.message)); }, []);

  const create = async (event) => {
    event.preventDefault();
    try {
      await api.post("/bookings", normalizePayload(form, bookingFields), session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const patch = async (id, action) => {
    try {
      await api.patch(`/bookings/${id}/${action}`, {}, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <Header title="Bookings" subtitle="Users can reserve seats; admins can monitor all bookings." />
      {session.role === "USER" && (
        <form className="editor compact" onSubmit={create}>
          {bookingFields.map((field) => <Field key={field.name} {...field} value={form[field.name]} onChange={(value) => setForm({ ...form, [field.name]: value })} />)}
          <button className="primary">Reserve seat</button>
        </form>
      )}
      {error && <div className="error">{error}</div>}
      <DataTable rows={rows} extraActions={(row) => (
        <>
          {session.role === "USER" && <button onClick={() => patch(row.id, "cancel")}>Cancel</button>}
          <button onClick={() => patch(row.id, "confirm-payment")}>Confirm payment</button>
        </>
      )} />
    </section>
  );
}

function Passengers({ session }) {
  return <SimpleCreateList title="Passengers" resource="passengers" empty={emptyPassenger} fields={passengerFields} session={session} />;
}

function Payments({ session }) {
  return <SimpleCreateList title="Payments" resource="payments" empty={emptyPayment} fields={paymentFields} session={session} />;
}

function Tickets({ session }) {
  return <SimpleCreateList title="Tickets" resource="tickets" empty={emptyTicket} fields={ticketFields} session={session} deletable />;
}

function SimpleCreateList({ title, resource, empty, fields, session, deletable = false }) {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");

  const load = async () => setRows(rowsOf(await api.get(`/${resource}`, session)));
  useEffect(() => { load().catch((err) => setError(err.message)); }, [resource]);

  const create = async (event) => {
    event.preventDefault();
    try {
      await api.post(`/${resource}`, normalizePayload(form, fields), session);
      setForm(empty);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (row) => {
    try {
      await api.delete(`/${resource}/${row.id || row.passengerId}`, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <Header title={title} subtitle="Connected directly to the matching backend endpoint." />
      {session.role === "USER" && (
        <form className="editor compact" onSubmit={create}>
          {fields.map((field) => <Field key={field.name} {...field} value={form[field.name]} onChange={(value) => setForm({ ...form, [field.name]: value })} />)}
          <button className="primary">Create</button>
        </form>
      )}
      {error && <div className="error">{error}</div>}
      <DataTable rows={rows} onDelete={deletable ? remove : undefined} />
    </section>
  );
}

function DataTable({ rows, onEdit, onDelete, extraActions }) {
  const columns = useMemo(() => Array.from(new Set(rows.flatMap((row) => Object.keys(row || {})))).slice(0, 10), [rows]);
  if (!rows.length) return <div className="empty">No records found.</div>;
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {columns.map((column) => <th key={column}>{column}</th>)}
            {(onEdit || onDelete || extraActions) && <th>actions</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={row.id || row.passengerId || row.ticketNumber || index}>
              {columns.map((column) => <td key={column}>{format(row[column])}</td>)}
              {(onEdit || onDelete || extraActions) && (
                <td className="row-actions">
                  {onEdit && <button onClick={() => onEdit(row)}>Edit</button>}
                  {onDelete && <button onClick={() => onDelete(row)}>Delete</button>}
                  {extraActions?.(row)}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Header({ title, subtitle }) {
  return (
    <header className="page-header">
      <h1>{title}</h1>
      <p>{subtitle}</p>
    </header>
  );
}

function Field({ label, name, value, onChange, type = "text", options }) {
  const id = name || label.toLowerCase().replaceAll(" ", "-");
  return (
    <label className="field" htmlFor={id}>
      <span>{label}</span>
      {options ? (
        <select id={id} value={value} onChange={(event) => onChange(event.target.value)}>
          {options.map((option) => <option key={option} value={option}>{option}</option>)}
        </select>
      ) : (
        <input id={id} type={type} value={value} onChange={(event) => onChange(event.target.value)} />
      )}
    </label>
  );
}

const flightFields = [
  { name: "flightNumber", label: "Flight number" },
  { name: "airlineName", label: "Airline name" },
  { name: "source", label: "Source" },
  { name: "destination", label: "Destination" },
  { name: "price", label: "Price", type: "number" },
  { name: "status", label: "Status", options: ["SCHEDULED", "DELAYED", "CANCELLED", "COMPLETED"] },
  { name: "aircraftId", label: "Aircraft ID", type: "number" },
];
const aircraftFields = [{ name: "modelNo", label: "Model number" }, { name: "totalSeats", label: "Total seats", type: "number" }];
const scheduleFields = [
  { name: "departureDate", label: "Departure date", type: "date" },
  { name: "departureTime", label: "Departure time", type: "time" },
  { name: "arrivalTime", label: "Arrival time", type: "time" },
  { name: "flightId", label: "Flight ID", type: "number" },
];
const seatFields = [
  { name: "seatNumber", label: "Seat number" },
  { name: "seatClass", label: "Seat class", options: ["ECONOMY", "PREMIUM_ECONOMY", "BUSINESS", "FIRST"] },
  { name: "seatType", label: "Seat type", options: ["WINDOW", "AISLE", "MIDDLE"] },
  { name: "aircraftId", label: "Aircraft ID", type: "number" },
];
const emptyUser = { firstName: "", lastName: "", email: "", phoneNumber: "", password: "", role: "USER" };
const userFields = [
  { name: "firstName", label: "First name" },
  { name: "lastName", label: "Last name" },
  { name: "email", label: "Email", type: "email" },
  { name: "phoneNumber", label: "Phone number" },
  { name: "password", label: "Password", type: "password" },
  { name: "role", label: "Role", options: ["USER", "ADMIN"] },
];
const bookingFields = [{ name: "userId", label: "User ID", type: "number" }, { name: "scheduleId", label: "Schedule ID", type: "number" }, { name: "seatId", label: "Seat ID", type: "number" }];
const emptyPassenger = { firstName: "", lastName: "", gender: "MALE", dateOfBirth: "", passportNumber: "", nationality: "", bookingId: "" };
const passengerFields = [
  { name: "firstName", label: "First name" },
  { name: "lastName", label: "Last name" },
  { name: "gender", label: "Gender", options: ["MALE", "FEMALE", "OTHER"] },
  { name: "dateOfBirth", label: "Date of birth", type: "date" },
  { name: "passportNumber", label: "Passport number" },
  { name: "nationality", label: "Nationality" },
  { name: "bookingId", label: "Booking ID", type: "number" },
];
const emptyPayment = { bookingId: "", paymentMethod: "UPI" };
const paymentFields = [{ name: "bookingId", label: "Booking ID", type: "number" }, { name: "paymentMethod", label: "Payment method", options: ["UPI", "CREDIT_CARD", "DEBIT_CARD", "NET_BANKING", "WALLET"] }];
const emptyTicket = { bookingId: "" };
const ticketFields = [{ name: "bookingId", label: "Booking ID", type: "number" }];

function iconFor(tab) {
  const props = { size: 18 };
  return { dashboard: <Shield {...props} />, search: <Search {...props} />, flights: <Plane {...props} />, aircraft: <Plane {...props} />, schedules: <CalendarClock {...props} />, seats: <Armchair {...props} />, users: <Users {...props} />, bookings: <Ticket {...props} />, passengers: <User {...props} />, payments: <CreditCard {...props} />, tickets: <Ticket {...props} /> }[tab];
}

function labelFor(tab) {
  return tab[0].toUpperCase() + tab.slice(1);
}

function rowsOf(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.content)) return data.content;
  return data ? [data] : [];
}

function normalizePayload(form, fields) {
  return Object.fromEntries(fields.map((field) => {
    const value = form[field.name];
    return [field.name, field.type === "number" && value !== "" ? Number(value) : value];
  }));
}

function clean(object) {
  return Object.fromEntries(Object.entries(object).filter(([, value]) => value !== ""));
}

function pick(object, keys) {
  return Object.fromEntries(keys.map((key) => [key, object[key]]));
}

function format(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

createRoot(document.getElementById("root")).render(<App />);
