import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Armchair,
  CalendarClock,
  CreditCard,
  Download,
  History,
  LogOut,
  Plane,
  Search,
  Shield,
  Ticket,
  User,
  UserCog,
  Users,
} from "lucide-react";
import { api } from "./lib/api";
import "./styles.css";

const emptyFlight = {
  flightNumber: "",
  airlineName: "",
  source: "",
  destination: "",
  price: "",
  status: "SCHEDULED",
  aircraftId: "",
};

// Mirrors the backend defaults (BookingServiceImpl's windowSurcharge /
// aisleSurcharge, configurable via application.properties as
// skybook.pricing.seat-surcharge.window / .aisle). This is only used to
// render the pre-reservation estimate below — the authoritative amount is
// whatever the server returns in the booking response's baseFare /
// seatSurcharge / gstAmount / totalAmount fields once a seat is actually
// reserved. If you change the surcharge in application.properties, update
// this constant to match so the estimate doesn't drift from reality.
const SEAT_TYPE_SURCHARGE = { WINDOW: 350, AISLE: 200, MIDDLE: 0 };

// Minimal inline-validation helper: given a form object and a list of field
// configs, returns { fieldName: "message" } for any required value that's
// empty. Used to drive per-field error text instead of one global banner.
function validateRequired(form, fields) {
  const errors = {};
  fields.forEach((field) => {
    if (field.optional) return;
    const value = form[field.name];
    if (value === "" || value === null || value === undefined) {
      errors[field.name] = `${field.label} is required.`;
    }
  });
  return errors;
}

const emptyAircraft = { modelNo: "", totalSeats: "" };
const emptySchedule = { departureDate: "", departureTime: "", arrivalTime: "", flightId: "" };
const emptySeat = { seatNumber: "", seatClass: "ECONOMY", seatType: "WINDOW", aircraftId: "" };

const roleTabs = {
  USER: ["search", "bookings", "passengers", "history", "tickets", "profile"],
  ADMIN: ["dashboard", "search", "flights", "aircraft", "fleet", "schedules", "seats", "users", "bookings", "tickets"],
};

function App() {
  const [session, setSession] = useState(() => {
    const raw = localStorage.getItem("skybook.session");
    return raw ? JSON.parse(raw) : null;
  });
  const [active, setActive] = useState(session?.role === "ADMIN" ? "dashboard" : "search");
  const [paymentBookings, setPaymentBookings] = useState(null);
  // Set by the "Book now" CTA on a flight search result. Bookings reads this
  // once, to try to jump straight to that flight's schedule, then clears it.
  const [bookingIntentFlightId, setBookingIntentFlightId] = useState(null);
  // Admin equivalent of the CTA above. Admins can't create bookings — the
  // backend's createBooking/createBookings endpoints are @PreAuthorize
  // "hasRole('USER')" only — so "Book now" for an admin instead narrows the
  // bookings monitoring view to that specific flight's bookings.
  const [adminFlightFilter, setAdminFlightFilter] = useState(null);
  // Controls what a logged-out visitor sees: the landing page, or the auth
  // form (with a preset login/register tab, set by the navbar buttons).
  const [publicView, setPublicView] = useState({ screen: "landing", authMode: "login" });

  useEffect(() => {
    if (session) localStorage.setItem("skybook.session", JSON.stringify(session));
    else localStorage.removeItem("skybook.session");
  }, [session]);

  const signOut = () => {
    setSession(null);
    setActive("search");
    setPublicView({ screen: "landing", authMode: "login" });
  };

  const goToPayment = (bookings) => {
    setPaymentBookings(bookings);
    setActive("pay-now");
  };

  const leavePayment = () => {
    setPaymentBookings(null);
    setActive("bookings");
  };

  const bookFlight = (flightId) => {
    setBookingIntentFlightId(flightId);
    setActive("bookings");
  };

  const viewFlightBookings = (flightId) => {
    setAdminFlightFilter(flightId);
    setActive("bookings");
  };

  if (!session) {
    if (publicView.screen === "auth") {
      return (
        <AuthScreen
          initialMode={publicView.authMode}
          onAuth={setSession}
          onBack={() => setPublicView({ screen: "landing", authMode: "login" })}
        />
      );
    }
    return (
      <LandingPage
        onLogin={() => setPublicView({ screen: "auth", authMode: "login" })}
        onRegister={() => setPublicView({ screen: "auth", authMode: "register" })}
      />
    );
  }

  const tabs = roleTabs[session.role] || roleTabs.USER;

  // ...rest of App stays exactly as it was (the <div className="shell"> block)
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <Plane size={26} />
          <div>
            <strong>SkyBook</strong>
            <span>{session.role === "ADMIN" ? "Admin console" : "Booking desk"}</span>
          </div>
        </div>
        <nav>
          {tabs.map((tab) => (
            <button
              key={tab}
              className={active === tab ? "nav-item active" : "nav-item"}
              onClick={() => setActive(tab)}
              title={labelFor(tab)}
            >
              {iconFor(tab)}
              <span>{labelFor(tab)}</span>
            </button>
          ))}
        </nav>
        <div className="account">
          <div className="avatar">{session.email.slice(0, 1).toUpperCase()}</div>
          <div>
            <strong>{session.email}</strong>
            <span>{session.role}</span>
          </div>
          <button className="icon-button" onClick={signOut} title="Sign out">
            <LogOut size={18} />
          </button>
        </div>
      </aside>
      <main className="workspace">
        {active === "dashboard" && <AdminDashboard session={session} />}
        {active === "search" && (
          <FlightSearch session={session} onBook={session.role === "ADMIN" ? viewFlightBookings : bookFlight} />
        )}
        {active === "flights" && (
          <CrudPanel
            title="Flights"
            resource="flights"
            empty={emptyFlight}
            fields={flightFields}
            idKey="id"
            session={session}
            extraActions={(row) => (
              <button type="button" className="primary cta-small" onClick={() => viewFlightBookings(row.id)}>
                View bookings
              </button>
            )}
          />
        )}
        {active === "aircraft" && (
          <CrudPanel title="Aircraft" resource="aircrafts" empty={emptyAircraft} fields={aircraftFields} idKey="id" session={session} />
        )}
        {active === "fleet" && <AircraftFleetView session={session} />}
        {active === "schedules" && (
          <CrudPanel title="Schedules" resource="schedules" empty={emptySchedule} fields={scheduleFields} idKey="id" session={session} />
        )}
        {active === "seats" && <AdminSeatsPanel session={session} />}
        {active === "users" && <AdminUsersPanel session={session} />}
        {active === "bookings" && (
          <Bookings
            session={session}
            onPay={goToPayment}
            intentFlightId={bookingIntentFlightId}
            onIntentConsumed={() => setBookingIntentFlightId(null)}
            adminFlightFilter={adminFlightFilter}
            onAdminFilterConsumed={() => setAdminFlightFilter(null)}
          />
        )}
        {active === "passengers" && (
          <SimpleCreateList
            title="Passengers"
            subtitle="Unique passengers by passport number — the same person may appear on several bookings."
            resource="passengers"
            empty={emptyPassenger}
            fields={passengerFields}
            session={session}
            dedupeBy="passportNumber"
          />
        )}
        {active === "history" && <PaymentHistory session={session} />}
        {active === "tickets" && <Tickets session={session} />}
        {active === "profile" && <Profile session={session} />}
        {active === "pay-now" && paymentBookings && paymentBookings.length > 0 && (
          <PaymentFlow bookings={paymentBookings} session={session} onDone={leavePayment} />
        )}
      </main>
    </div>
  );
}
function LandingPage({ onLogin, onRegister }) {
  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="landing">
      <header className="landing-nav">
        <div className="brand">
          <Plane size={24} />
          <strong>SkyBook</strong>
        </div>
        <nav className="landing-nav-links">
          <button type="button" onClick={() => scrollTo("home")}>Home</button>
          <button type="button" onClick={() => scrollTo("about")}>About</button>
          <button type="button" onClick={() => scrollTo("contact")}>Contact</button>
        </nav>
        <div className="landing-nav-actions">
          <button type="button" className="secondary" onClick={onLogin}>Login</button>
          <button type="button" className="primary" onClick={onRegister}>Register</button>
        </div>
      </header>

      <section id="home" className="landing-hero">
        <div className="landing-hero-copy">
          <h1>Book flights the way operations teams do — fast, transparent, role-aware.</h1>
          <p>Search live schedules, pick your seat visually, and get your e-ticket by email in seconds.</p>
        </div>
        <LandingFlightSearch onLogin={onLogin} />
      </section>

      <section id="about" className="landing-section landing-about">
        <h2>About SkyBook</h2>
        <p>
          SkyBook is a flight booking platform built for clarity: real-time seat availability,
          transparent pricing with GST built in, and a single dashboard for both travelers and
          airline operations staff.
        </p>
        <div className="landing-feature-grid">
          <article className="landing-feature">
            <Armchair size={22} />
            <h3>Visual seat selection</h3>
            <p>See the exact cabin layout — window, aisle, or middle — before you book.</p>
          </article>
          <article className="landing-feature">
            <Ticket size={22} />
            <h3>Instant e-tickets</h3>
            <p>Tickets are generated and emailed the moment payment is confirmed.</p>
          </article>
          <article className="landing-feature">
            <Shield size={22} />
            <h3>Role-aware console</h3>
            <p>Operations teams manage flights, aircraft, and schedules from one admin view.</p>
          </article>
        </div>
      </section>

      <section id="contact" className="landing-section landing-contact">
        <h2>Contact us</h2>
        <p>Have a question about a booking or partnering with SkyBook? Reach out.</p>
        <div className="landing-contact-grid">
          <div>
            <span>Email</span>
            <strong>support@skybook.com</strong>
          </div>
          <div>
            <span>Phone</span>
            <strong>+91 98765 43210</strong>
          </div>
          <div>
            <span>Office</span>
            <strong>Greater Noida, Uttar Pradesh, India</strong>
          </div>
        </div>
      </section>

      <footer className="landing-footer">
        <span>&copy; {new Date().getFullYear()} SkyBook. All rights reserved.</span>
      </footer>
    </div>
  );
}

// Public flight search card for the landing page — mirrors FlightSearch but
// doesn't require a session, since GET /flights/search is permitAll on the
// backend. Results just prompt sign-in to actually book.
function LandingFlightSearch({ onLogin }) {
  const [query, setQuery] = useState({ source: "", destination: "", departureDate: "" });
  const [results, setResults] = useState([]);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});

  const searchFields = [
    { name: "source", label: "Source" },
    { name: "destination", label: "Destination" },
    { name: "departureDate", label: "Departure date" },
  ];

  const search = async (event) => {
    event.preventDefault();
    setError("");
    const errors = validateRequired(query, searchFields);
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;
    const qs = new URLSearchParams(clean(query)).toString();
    try {
      setResults(rowsOf(await api.get(`/flights/search?${qs}`)));
      setSearched(true);
    } catch (err) {
      setError(err.message);
    }
  };

  const fieldProps = (name) => ({
    error: fieldErrors[name],
    onChange: (value) => {
      setQuery({ ...query, [name]: value });
      if (fieldErrors[name]) setFieldErrors({ ...fieldErrors, [name]: undefined });
    },
  });

  return (
    <div className="landing-search-card">
      <h3>Find your flight</h3>
      <form className="landing-search-form" onSubmit={search}>
        <Field label="Source" value={query.source} {...fieldProps("source")} />
        <Field label="Destination" value={query.destination} {...fieldProps("destination")} />
        <Field label="Departure date" type="date" value={query.departureDate} {...fieldProps("departureDate")} />
        <button className="primary icon-text"><Search size={18} />Search flights</button>
      </form>
      {error && <div className="error">{error}</div>}
      {searched && (
        results.length ? (
          <ul className="landing-results">
            {results.slice(0, 5).map((flight, index) => (
              <li key={flight.id || index}>
                <div className="landing-results-info">
                  <strong>{flight.flightNumber}</strong>
                  <span>{flight.source} &rarr; {flight.destination}</span>
                  <span>{flight.airlineName}</span>
                </div>
                <button type="button" className="secondary landing-results-cta" onClick={onLogin}>
                  Login to book
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="empty">No flights found for that route.</div>
        )
      )}
    </div>
  );
}

function AuthScreen({ onAuth, initialMode = "login", onBack }) {
  const [mode, setMode] = useState(initialMode);
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    password: "",
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});

  const authFields =
    mode === "login"
      ? [{ name: "email", label: "Email" }, { name: "password", label: "Password" }]
      : [
          { name: "firstName", label: "First name" },
          { name: "lastName", label: "Last name" },
          { name: "phoneNumber", label: "Phone number" },
          { name: "email", label: "Email" },
          { name: "password", label: "Password" },
        ];

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    const errors = validateRequired(form, authFields);
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;
    setBusy(true);
    try {
      const payload = mode === "login" ? pick(form, ["email", "password"]) : form;
      const data = await api.publicPost(`/auth/${mode}`, payload);
      onAuth({ ...data, role: data.role?.replace("ROLE_", "") });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const fieldProps = (name) => ({
    error: fieldErrors[name],
    onChange: (value) => {
      setForm({ ...form, [name]: value });
      if (fieldErrors[name]) setFieldErrors({ ...fieldErrors, [name]: undefined });
    },
  });

  return (
    <main className="auth-page">
      <section className="auth-panel">
        <div className="auth-copy">
          <div className="brand wide">
            <Plane size={30} />
            <div>
              <strong>SkyBook</strong>
              <span>Flight booking system</span>
            </div>
          </div>
          <h1>Operate flights, schedules, seats, bookings, and tickets from one role-aware console.</h1>
          <div className="role-strip">
            <span><Shield size={16} /> Admin CRUD</span>
            <span><User size={16} /> User bookings</span>
          </div>
          {onBack && (
            <button type="button" className="auth-back-link" onClick={onBack}>
              &larr; Back to SkyBook.com
            </button>
          )}
        </div>
        <form className="login-card" onSubmit={submit}>
          <div className="segmented">
            <button type="button" className={mode === "login" ? "selected" : ""} onClick={() => setMode("login")}>Login</button>
            <button type="button" className={mode === "register" ? "selected" : ""} onClick={() => setMode("register")}>Register</button>
          </div>
          {mode === "register" && (
            <div className="grid two">
              <Field label="First name" value={form.firstName} {...fieldProps("firstName")} />
              <Field label="Last name" value={form.lastName} {...fieldProps("lastName")} />
              <Field label="Phone number" value={form.phoneNumber} {...fieldProps("phoneNumber")} />
            </div>
          )}
          <Field label="Email" type="email" value={form.email} {...fieldProps("email")} />
          <Field label="Password" type="password" value={form.password} {...fieldProps("password")} />
          {error && <div className="error">{error}</div>}
          <button className="primary" disabled={busy}>{busy ? "Please wait..." : mode === "login" ? "Login" : "Create account"}</button>
        </form>
      </section>
    </main>
  );
}

function AdminDashboard({ session }) {
  const [stats, setStats] = useState([]);
  useEffect(() => {
    Promise.all(["flights", "aircrafts", "schedules", "seats", "bookings", "tickets"].map((r) => api.get(`/${r}`, session)))
      .then((data) => setStats(data.map((items, index) => ({ name: ["Flights", "Aircraft", "Schedules", "Seats", "Bookings", "Tickets"][index], count: rowsOf(items).length }))))
      .catch(() => setStats([]));
  }, [session]);
  return (
    <section>
      <Header title="Operations Dashboard" subtitle="Live counts from the Spring Boot API." />
      <div className="metric-grid">
        {stats.map((item) => (
          <article className="metric" key={item.name}>
            <span>{item.name}</span>
            <strong>{item.count}</strong>
          </article>
        ))}
      </div>
    </section>
  );
}

function FlightSearch({ session, onBook }) {
  const [query, setQuery] = useState({ source: "", destination: "", departureDate: "" });
  const [results, setResults] = useState([]);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
  const isAdmin = session.role === "ADMIN";

  const searchFields = [
    { name: "source", label: "Source" },
    { name: "destination", label: "Destination" },
    { name: "departureDate", label: "Departure date" },
  ];

  const search = async (event) => {
    event.preventDefault();
    setError("");
    const errors = validateRequired(query, searchFields);
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;
    const qs = new URLSearchParams(clean(query)).toString();
    try {
      setResults(rowsOf(await api.get(`/flights/search?${qs}`, session)));
    } catch (err) {
      setError(err.message);
    }
  };

  const fieldProps = (name) => ({
    error: fieldErrors[name],
    onChange: (value) => {
      setQuery({ ...query, [name]: value });
      if (fieldErrors[name]) setFieldErrors({ ...fieldErrors, [name]: undefined });
    },
  });

  return (
    <section>
      <Header
        title="Find Flights"
        subtitle={isAdmin ? "Search flights and jump straight to their bookings." : "Search public flight availability and create bookings as a user."}
      />
      <form className="toolbar" onSubmit={search}>
        <Field label="Source" value={query.source} {...fieldProps("source")} />
        <Field label="Destination" value={query.destination} {...fieldProps("destination")} />
        <Field label="Departure date" type="date" value={query.departureDate} {...fieldProps("departureDate")} />
        <button className="primary icon-text"><Search size={18} />Search</button>
      </form>
      {error && <div className="error">{error}</div>}
      <DataTable
        rows={results}
        extraActions={
          onBook
            ? (row) => (
                <button type="button" className="primary cta-small" onClick={() => onBook(row.id)}>
                  {isAdmin ? "View bookings" : "Book now"}
                </button>
              )
            : undefined
        }
      />
    </section>
  );
}

// Resources whose forms need a dropdown backed by another resource
// (Flights -> Aircraft, Schedules -> Flights).
const relatedResourceConfig = {
  flights: { field: "aircraftId", resource: "aircrafts", label: (a) => `${a.modelNo} (${a.totalSeats} seats)` },
  schedules: { field: "flightId", resource: "flights", label: (f) => `${f.flightNumber} · ${f.source} → ${f.destination}` },
};

function CrudPanel({ title, resource, empty, fields, idKey, session, hideCreateForm = false, note, extraActions }) {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
  const [relatedOptions, setRelatedOptions] = useState([]);
  const relatedConfig = relatedResourceConfig[resource];

  const load = async () => {
    setError("");
    try {
      setRows(rowsOf(await api.get(`/${resource}`, session)));
    } catch (err) {
      setError(err.message);
    }
  };

  const loadRelated = async () => {
    if (!relatedConfig) return;
    try {
      setRelatedOptions(rowsOf(await api.get(`/${relatedConfig.resource}`, session)));
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    load();
    loadRelated();
  }, [resource]);

  const save = async (event) => {
    event.preventDefault();
    setError("");
    const errors = validateRequired(form, fields);
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;
    try {
      const payload = normalizePayload(form, fields);
      if (editing) await api.put(`/${resource}/${editing}`, payload, session);
      else await api.post(`/${resource}`, payload, session);
      setForm(empty);
      setEditing(null);
      setFieldErrors({});
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const edit = (row) => {
    setEditing(row[idKey]);
    setForm(Object.fromEntries(Object.keys(empty).map((key) => [key, row[key] ?? ""])));
  };

  const remove = async (row) => {
    setError("");
    try {
      await api.delete(`/${resource}/${row[idKey]}`, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const processedFields = fields.map((field) => {
    if (relatedConfig && field.name === relatedConfig.field) {
      return {
        ...field,
        options: relatedOptions.map((item) => ({ value: item.id, label: relatedConfig.label(item) })),
      };
    }
    return field;
  });

  return (
    <section>
      <Header title={title} subtitle={note || "Create, update, and remove records available to admins."} />
      {!hideCreateForm && (
        <form className="editor" onSubmit={save}>
          {processedFields.map((field) => (
            <Field
              key={field.name}
              {...field}
              value={form[field.name] ?? ""}
              error={fieldErrors[field.name]}
              onChange={(value) => {
                setForm({ ...form, [field.name]: value });
                if (fieldErrors[field.name]) setFieldErrors({ ...fieldErrors, [field.name]: undefined });
              }}
            />
          ))}
          <div className="form-actions">
            <button className="primary">{editing ? "Update" : "Create"}</button>
            {editing && <button type="button" className="secondary" onClick={() => { setEditing(null); setForm(empty); setFieldErrors({}); }}>Cancel</button>}
          </div>
        </form>
      )}
      {error && <div className="error">{error}</div>}
      <DataTable rows={rows} onEdit={hideCreateForm ? undefined : edit} onDelete={remove} extraActions={extraActions} />
    </section>
  );
}

// Admin can only ever change a user's role. Assumes the backend exposes
// PATCH /users/{id}/role — if it only has PUT /users/{id}, make sure that
// endpoint ignores/rejects any field other than role when called by an admin.
function AdminUsersPanel({ session }) {
  const [rows, setRows] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [role, setRole] = useState("USER");
  const [error, setError] = useState("");

  const load = async () => {
    setError("");
    try {
      setRows(rowsOf(await api.get("/users", session)));
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const startEdit = (row) => {
    setEditingId(row.id);
    setRole(row.role || "USER");
  };

  const saveRole = async (row) => {
    setError("");
    try {
      await api.patch(`/users/${row.id}/role`, { role }, session);
      setEditingId(null);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const removeUser = async (row) => {
    if (!window.confirm(`Delete ${row.email}? This cannot be undone.`)) return;
    setError("");
    try {
      await api.delete(`/users/${row.id}`, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <Header title="Users" subtitle="Admins can only change a user's role, not their personal details." />
      {error && <div className="error">{error}</div>}
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Role</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td>{row.firstName} {row.lastName}</td>
                <td>{row.email}</td>
                <td>{row.phoneNumber}</td>
                <td>
                  {editingId === row.id ? (
                    <select value={role} onChange={(event) => setRole(event.target.value)}>
                      <option value="USER">USER</option>
                      <option value="ADMIN">ADMIN</option>
                    </select>
                  ) : (
                    row.role
                  )}
                </td>
                <td className="row-actions">
                  {editingId === row.id ? (
                    <>
                      <button onClick={() => saveRole(row)}>Save</button>
                      <button onClick={() => setEditingId(null)}>Cancel</button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => startEdit(row)}>Edit role</button>
                      <button onClick={() => removeUser(row)}>Delete</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
            {!rows.length && (
              <tr>
                <td colSpan={5} className="empty">No users found.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

// Parses "12A" into { row: 12, letter: "A" }
function parseSeat(seatNumber) {
  const match = /^(\d+)([A-Za-z])$/.exec(seatNumber || "");
  if (!match) return { row: 0, letter: "" };
  return { row: Number(match[1]), letter: match[2].toUpperCase() };
}

function SeatMap({ seats, selectedSeatIds, onToggle }) {
  const rows = useMemo(() => {
    const byRow = new Map();
    seats.forEach((seat) => {
      const { row, letter } = parseSeat(seat.seatNumber);
      if (!byRow.has(row)) byRow.set(row, {});
      byRow.get(row)[letter] = seat;
    });
    return Array.from(byRow.entries()).sort((a, b) => a[0] - b[0]);
  }, [seats]);

  // Rows are generated contiguously by class (see AircraftServiceImpl.resolveClass),
  // so grouping consecutive rows that share a class gives clean sections —
  // reads the class straight off the seat data rather than re-deriving it
  // from row numbers, so it stays correct even if that backend logic changes.
  const sections = useMemo(() => {
    const result = [];
    let current = null;
    rows.forEach(([rowNumber, seatsInRow]) => {
      const seatClass = Object.values(seatsInRow).find(Boolean)?.seatClass || "UNKNOWN";
      if (!current || current.seatClass !== seatClass) {
        current = { seatClass, rows: [] };
        result.push(current);
      }
      current.rows.push([rowNumber, seatsInRow]);
    });
    return result;
  }, [rows]);

  const leftCols = ["A", "B", "C"];
  const rightCols = ["D", "E", "F"];

  if (!rows.length) return <div className="empty">No seats available for this schedule.</div>;

  return (
    <div className="seat-map">
      <div className="seat-map-header">
        <span className="seat-map-row-label" />
        {leftCols.map((letter) => <span key={letter} className="seat-map-col-label">{letter}</span>)}
        <span className="seat-map-aisle-label" />
        {rightCols.map((letter) => <span key={letter} className="seat-map-col-label">{letter}</span>)}
      </div>
      {sections.map((section, sectionIndex) => (
        <div className="seat-map-section" key={sectionIndex}>
          <div className="seat-map-section-title">
            <span>{formatSeatClass(section.seatClass)}</span>
          </div>
          {section.rows.map(([rowNumber, seatsInRow]) => (
            <div className="seat-map-row" key={rowNumber}>
              <span className="seat-map-row-label">{rowNumber}</span>
              {leftCols.map((letter) => (
                <SeatCell key={letter} seat={seatsInRow[letter]} selectedSeatIds={selectedSeatIds} onToggle={onToggle} />
              ))}
              <span className="seat-map-aisle" />
              {rightCols.map((letter) => (
                <SeatCell key={letter} seat={seatsInRow[letter]} selectedSeatIds={selectedSeatIds} onToggle={onToggle} />
              ))}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function formatSeatClass(seatClass) {
  return String(seatClass || "")
    .split("_")
    .map((word) => word.charAt(0) + word.slice(1).toLowerCase())
    .join(" ");
}

function SeatCell({ seat, selectedSeatIds, onToggle }) {
  if (!seat) return <span className="seat-map-empty" />;
  const isBooked = seat.status === "BOOKED";
  const isSelected = selectedSeatIds.includes(seat.seatId);
  return (
    <button
      type="button"
      disabled={isBooked}
      className={`seat-cell ${isBooked ? "booked" : "available"} ${isSelected ? "selected" : ""}`}
      onClick={() => onToggle(seat)}
      title={`${seat.seatNumber} · ${seat.seatClass} · ${seat.seatType}`}
    >
      {seat.seatNumber}
    </button>
  );
}
const emptyPassengerForm = { firstName: "", lastName: "", gender: "MALE", dateOfBirth: "", passportNumber: "", nationality: "" };

function Bookings({ session, onPay, intentFlightId, onIntentConsumed, adminFlightFilter, onAdminFilterConsumed }) {
  const isAdmin = session.role === "ADMIN";
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");

  const [schedules, setSchedules] = useState([]);
  const schedulesById = useMemo(() => Object.fromEntries(schedules.map((s) => [s.id, s])), [schedules]);
  const [flightsById, setFlightsById] = useState({});
  const [step, setStep] = useState("choose-schedule");
  const [selectedSchedule, setSelectedSchedule] = useState(null);
  const [seats, setSeats] = useState([]);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [passengerForms, setPassengerForms] = useState({}); // seatId -> form
  const [passengerFieldErrors, setPassengerFieldErrors] = useState({}); // seatId -> { field: message }
  const [reserving, setReserving] = useState(false);

  const load = async () => {
    setError("");
    try {
      setRows(rowsOf(await api.get("/bookings", session)));
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    Promise.all([api.get("/schedules", session), api.get("/flights", session)])
      .then(([scheduleData, flightData]) => {
        setSchedules(rowsOf(scheduleData));
        setFlightsById(Object.fromEntries(rowsOf(flightData).map((f) => [f.id, f])));
      })
      .catch((err) => setError(err.message));
  }, []);

  // If the user arrived here via a "Book now" CTA on a search result, try to
  // jump straight to a schedule for that flight once schedules have loaded.
  // If there's more than one schedule for the flight, we fall back to the
  // normal picker instead of guessing which departure they want.
  useEffect(() => {
    if (isAdmin || !intentFlightId || !schedules.length) return;
    const matches = schedules.filter((s) => s.flightId === intentFlightId);
    if (matches.length === 1) pickSchedule(matches[0]);
    onIntentConsumed?.();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin, intentFlightId, schedules]);

  const pickSchedule = async (schedule) => {
    setSelectedSchedule(schedule);
    setSelectedSeats([]);
    setPassengerForms({});
    setStep("choose-seat");
    setError("");
    try {
      setSeats(rowsOf(await api.get(`/seats/availability/${schedule.id}`, session)));
    } catch (err) {
      setError(err.message);
    }
  };

  const toggleSeat = (seat) => {
    if (seat.status === "BOOKED") return;
    setSelectedSeats((current) => {
      const alreadyPicked = current.some((s) => s.seatId === seat.seatId);
      if (alreadyPicked) {
        setPassengerForms((forms) => {
          const next = { ...forms };
          delete next[seat.seatId];
          return next;
        });
        return current.filter((s) => s.seatId !== seat.seatId);
      }
      setPassengerForms((forms) => ({ ...forms, [seat.seatId]: emptyPassengerForm }));
      return [...current, seat];
    });
  };

  const updatePassengerField = (seatId, field, value) => {
    setPassengerForms((forms) => ({
      ...forms,
      [seatId]: { ...forms[seatId], [field]: value },
    }));
  };

  const goToPassengerStep = () => {
    if (!selectedSeats.length) return;
    setStep("passenger-details");
  };

  const requiredPassengerFields = [
    { name: "firstName", label: "First name" },
    { name: "lastName", label: "Last name" },
    { name: "dateOfBirth", label: "Date of birth" },
    { name: "passportNumber", label: "Passport number" },
    { name: "nationality", label: "Nationality" },
  ];

  const reserve = async () => {
    if (!selectedSchedule || !selectedSeats.length) return;
    setError("");

    const nextErrors = {};
    selectedSeats.forEach((seat) => {
      const errs = validateRequired(passengerForms[seat.seatId] || {}, requiredPassengerFields);
      if (Object.keys(errs).length) nextErrors[seat.seatId] = errs;
    });
    setPassengerFieldErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;

    setReserving(true);
    try {
      const seats = selectedSeats.map((seat) => ({
        seatId: seat.seatId,
        passenger: passengerForms[seat.seatId],
      }));
      const created = await api.post("/bookings/batch", { scheduleId: selectedSchedule.id, seats }, session);
      setStep("choose-schedule");
      setSelectedSchedule(null);
      setSelectedSeats([]);
      setPassengerForms({});
      await load();
      onPay(rowsOf(created));
    } catch (err) {
      setError(err.message);
    } finally {
      setReserving(false);
    }
  };

  const cancel = async (id) => {
    setError("");
    try {
      await api.patch(`/bookings/${id}/cancel`, {}, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const allPassengerFormsFilled = selectedSeats.every((seat) => {
    const form = passengerForms[seat.seatId];
    return form && form.firstName && form.lastName && form.dateOfBirth && form.passportNumber && form.nationality;
  });

  return (
    <section>
      <Header
        title="Bookings"
        subtitle={isAdmin ? "Monitor every booking made on the platform." : "Pick a schedule, choose your seats, and add passenger details."}
      />
      {error && <div className="error">{error}</div>}

      {!isAdmin && (
        <div className="booking-flow">
          {step === "choose-schedule" && (
            <div className="schedule-grid">
              {schedules.map((schedule) => {
                const flight = flightsById[schedule.flightId];
                return (
                  <button key={schedule.id} type="button" className="schedule-card" onClick={() => pickSchedule(schedule)}>
                    <strong>{flight ? `${flight.source} → ${flight.destination}` : `Flight #${schedule.flightId}`}</strong>
                    <span className="mono">{flight?.flightNumber}</span>
                    <span className="mono">Departs {schedule.departureDate} · {schedule.departureTime}</span>
                    <span className="mono">Arrives {schedule.arrivalDate} · {schedule.arrivalTime}</span>
                  </button>
                );
              })}
              {!schedules.length && <div className="empty">No schedules available right now.</div>}
            </div>
          )}

          {step === "choose-seat" && selectedSchedule && (
            <div className="seat-picker">
              <button type="button" className="secondary" onClick={() => setStep("choose-schedule")}>&larr; Back to schedules</button>
              <SeatMap seats={seats} selectedSeatIds={selectedSeats.map((s) => s.seatId)} onToggle={toggleSeat} />
              <div className="seat-legend">
                <span><i className="legend-dot available" /> Available</span>
                <span><i className="legend-dot selected" /> Selected</span>
                <span><i className="legend-dot booked" /> Booked</span>
              </div>
              <div className="seat-summary">
                {selectedSeats.length > 0
                  ? <span>{selectedSeats.length} seat{selectedSeats.length > 1 ? "s" : ""} selected: {selectedSeats.map((s) => s.seatNumber).join(", ")}</span>
                  : <span>Select one or more seats.</span>}
              </div>
              <button className="primary" disabled={!selectedSeats.length} onClick={goToPassengerStep}>
                Continue to passenger details
              </button>
            </div>
          )}

          {step === "passenger-details" && selectedSchedule && (
            <div className="passenger-details-flow">
              <button type="button" className="secondary" onClick={() => setStep("choose-seat")}>&larr; Back to seat selection</button>
              <PriceBreakdown
                baseFare={Number(flightsById[selectedSchedule.flightId]?.price || 0)}
                seats={selectedSeats}
              />
              {selectedSeats.map((seat) => (
                <div className="passenger-form-card" key={seat.seatId}>
                  <h4>Seat {seat.seatNumber} &middot; {seat.seatClass}</h4>
                  <div className="editor compact">
                    {[
                      ["firstName", "First name", "text"],
                      ["lastName", "Last name", "text"],
                    ].map(([name, label]) => (
                      <Field
                        key={name}
                        label={label}
                        value={passengerForms[seat.seatId]?.[name] ?? ""}
                        error={passengerFieldErrors[seat.seatId]?.[name]}
                        onChange={(v) => {
                          updatePassengerField(seat.seatId, name, v);
                          if (passengerFieldErrors[seat.seatId]?.[name]) {
                            setPassengerFieldErrors((cur) => ({ ...cur, [seat.seatId]: { ...cur[seat.seatId], [name]: undefined } }));
                          }
                        }}
                      />
                    ))}
                    <Field label="Gender" value={passengerForms[seat.seatId]?.gender ?? "MALE"} onChange={(v) => updatePassengerField(seat.seatId, "gender", v)} options={["MALE", "FEMALE", "OTHER"]} />
                    {[
                      ["dateOfBirth", "Date of birth", "date"],
                      ["passportNumber", "Passport number", "text"],
                      ["nationality", "Nationality", "text"],
                    ].map(([name, label, type]) => (
                      <Field
                        key={name}
                        label={label}
                        type={type}
                        value={passengerForms[seat.seatId]?.[name] ?? ""}
                        error={passengerFieldErrors[seat.seatId]?.[name]}
                        onChange={(v) => {
                          updatePassengerField(seat.seatId, name, v);
                          if (passengerFieldErrors[seat.seatId]?.[name]) {
                            setPassengerFieldErrors((cur) => ({ ...cur, [seat.seatId]: { ...cur[seat.seatId], [name]: undefined } }));
                          }
                        }}
                      />
                    ))}
                  </div>
                </div>
              ))}
              <button className="primary" disabled={reserving} onClick={reserve}>
                {reserving ? "Reserving..." : `Reserve ${selectedSeats.length} seat${selectedSeats.length === 1 ? "" : "s"}`}
              </button>
            </div>
          )}
        </div>
      )}

      {isAdmin && adminFlightFilter && (
        <div className="group-reference-banner">
          Showing bookings for flight #{adminFlightFilter} only.{" "}
          <button type="button" className="secondary cta-small" onClick={onAdminFilterConsumed}>Clear filter</button>
        </div>
      )}

      <DataTable
        rows={
          isAdmin && adminFlightFilter
            ? rows.filter((r) => schedulesById[r.scheduleId]?.flightId === adminFlightFilter)
            : rows
        }
        extraActions={
          isAdmin
            ? undefined
            : (row) => (
                <>
                  {row.bookingStatus !== "CONFIRMED" && row.bookingStatus !== "CANCELLED" && (
                    <>
                      <button onClick={() => cancel(row.id)}>Cancel</button>
                      <button onClick={() => onPay([row])}>Pay now</button>
                    </>
                  )}
                </>
              )
        }
      />
    </section>
  );
}

// Client-side price estimate for the seats currently selected in the
// booking flow. Surcharges here are NOT charged by the backend today (see
// SEAT_TYPE_SURCHARGE) — this exists so the user isn't surprised later, and
// should be replaced with real figures once the API returns per-seat pricing.
function PriceBreakdown({ baseFare, seats }) {
  const rows = seats.map((seat) => ({
    seat,
    surcharge: SEAT_TYPE_SURCHARGE[seat.seatType] ?? 0,
  }));
  const fareTotal = baseFare * seats.length;
  const surchargeTotal = rows.reduce((sum, r) => sum + r.surcharge, 0);
  const tax = Math.round((fareTotal + surchargeTotal) * 0.05); // GST estimate, 5%
  const grandTotal = fareTotal + surchargeTotal + tax;

  return (
    <div className="price-breakdown">
      <h4>Estimated price</h4>
      <ul className="price-breakdown-lines">
        <li>
          <span>Base fare &times; {seats.length}</span>
          <span className="mono">₹{fareTotal.toFixed(2)}</span>
        </li>
        {rows.map(({ seat, surcharge }) => (
          <li key={seat.seatId} className="price-breakdown-subline">
            <span>Seat {seat.seatNumber} &middot; {seat.seatType.toLowerCase()}{surcharge ? " preference" : ""}</span>
            <span className="mono">{surcharge ? `+₹${surcharge.toFixed(2)}` : "included"}</span>
          </li>
        ))}
        <li>
          <span>Taxes (GST, est. 5%)</span>
          <span className="mono">₹{tax.toFixed(2)}</span>
        </li>
      </ul>
      <div className="price-breakdown-total">
        <span>Estimated total</span>
        <span className="mono">₹{grandTotal.toFixed(2)}</span>
      </div>
      <p className="price-breakdown-note">
        Estimate — matches the server's pricing rules, but the confirmed, itemized amount is returned when you reserve.
      </p>
    </div>
  );
}

// Admin-only: pick an aircraft and see its full seat layout, independent of
// any specific schedule. Reuses SeatMap in a read-only "reference" mode
// (no booked/selected states, since these are raw aircraft seat records).
function AircraftFleetView({ session }) {
  const [aircraftList, setAircraftList] = useState([]);
  const [selectedAircraftId, setSelectedAircraftId] = useState("");
  const [seats, setSeats] = useState([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get("/aircrafts", session).then((data) => setAircraftList(rowsOf(data))).catch((err) => setError(err.message));
  }, []);

  useEffect(() => {
    if (!selectedAircraftId) {
      setSeats([]);
      return;
    }
    setLoading(true);
    setError("");
    api
      .get(`/seats/aircraft/${selectedAircraftId}`, session)
      .then((data) => setSeats(rowsOf(data)))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [selectedAircraftId]);

  // /seats returns raw seat records (seatNumber/seatClass/seatType/id), not
  // the availability-shaped records SeatMap normally expects (seatId/status).
  // Adapt the shape here so the fleet view can reuse the same grid component.
  const seatMapRows = seats.map((seat) => ({
    seatId: seat.id,
    seatNumber: seat.seatNumber,
    seatClass: seat.seatClass,
    seatType: seat.seatType,
    status: "AVAILABLE",
  }));

  return (
    <section>
      <Header title="Fleet Seat Map" subtitle="Visual seat layout for any aircraft model, independent of scheduling." />
      <Field
        label="Aircraft"
        value={selectedAircraftId}
        onChange={setSelectedAircraftId}
        options={aircraftList.map((a) => ({ value: a.id, label: `${a.modelNo} (${a.totalSeats} seats)` }))}
      />
      {error && <div className="error">{error}</div>}
      {!selectedAircraftId && <div className="empty">Select an aircraft to view its seat layout.</div>}
      {selectedAircraftId && loading && <div className="empty">Loading seat layout...</div>}
      {selectedAircraftId && !loading && <SeatMap seats={seatMapRows} selectedSeatIds={[]} onToggle={() => {}} />}
    </section>
  );
}

// Admin corrections view for seats — grouped by aircraft via a dropdown so
// the list stays scoped to one aircraft at a time instead of mixing every
// seat from every aircraft into one table.
function AdminSeatsPanel({ session }) {
  const [aircraftList, setAircraftList] = useState([]);
  const [selectedAircraftId, setSelectedAircraftId] = useState("");
  const [rows, setRows] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(emptySeat);
  const [fieldErrors, setFieldErrors] = useState({});
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    api.get("/aircrafts", session).then((data) => setAircraftList(rowsOf(data))).catch((err) => setError(err.message));
  }, []);

  const load = async (aircraftId) => {
    if (!aircraftId) {
      setRows([]);
      return;
    }
    setLoading(true);
    setError("");
    try {
      setRows(rowsOf(await api.get(`/seats/aircraft/${aircraftId}`, session)));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(selectedAircraftId);
    setEditingId(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedAircraftId]);

  const startEdit = (row) => {
    setEditingId(row.id);
    setForm({ seatNumber: row.seatNumber, seatClass: row.seatClass, seatType: row.seatType, aircraftId: selectedAircraftId });
    setFieldErrors({});
  };

  const save = async (event) => {
    event.preventDefault();
    setError("");
    const errors = validateRequired(form, seatFields);
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;
    try {
      await api.put(`/seats/${editingId}`, normalizePayload(form, seatFields), session);
      setEditingId(null);
      await load(selectedAircraftId);
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (row) => {
    if (!window.confirm(`Delete seat ${row.seatNumber}?`)) return;
    setError("");
    try {
      await api.delete(`/seats/${row.id}`, session);
      await load(selectedAircraftId);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <Header
        title="Seats"
        subtitle="Seats are generated automatically when an aircraft is created. Pick an aircraft below to review or correct its layout."
      />
      <Field
        label="Aircraft"
        value={selectedAircraftId}
        onChange={setSelectedAircraftId}
        options={aircraftList.map((a) => ({ value: a.id, label: `${a.modelNo} (${a.totalSeats} seats)` }))}
      />
      {error && <div className="error">{error}</div>}
      {!selectedAircraftId && <div className="empty">Select an aircraft to view its seats.</div>}
      {selectedAircraftId && loading && <div className="empty">Loading seats...</div>}

      {selectedAircraftId && !loading && editingId && (
        <form className="editor compact" onSubmit={save}>
          {seatFields.filter((f) => f.name !== "aircraftId").map((field) => (
            <Field
              key={field.name}
              {...field}
              value={form[field.name] ?? ""}
              error={fieldErrors[field.name]}
              onChange={(value) => {
                setForm({ ...form, [field.name]: value });
                if (fieldErrors[field.name]) setFieldErrors({ ...fieldErrors, [field.name]: undefined });
              }}
            />
          ))}
          <div className="form-actions">
            <button className="primary">Save</button>
            <button type="button" className="secondary" onClick={() => setEditingId(null)}>Cancel</button>
          </div>
        </form>
      )}

      {selectedAircraftId && !loading && !editingId && (
        <DataTable rows={rows} onEdit={startEdit} onDelete={remove} />
      )}
    </section>
  );
}

// USER-only: reached via the "Pay now" button on a booking, not from the sidebar.
function PaymentFlow({ bookings, session, onDone }) {
  const [method, setMethod] = useState("UPI");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const total = bookings.reduce((sum, b) => sum + Number(b.totalAmount || 0), 0);
  const groupRef = bookings[0]?.groupBookingReference;

  const confirm = async () => {
    setBusy(true);
    setError("");
    try {
      if (bookings.length === 1) {
        await api.post("/payments", { bookingId: bookings[0].id, paymentMethod: method }, session);
      } else {
        await api.post("/payments/batch", { bookingIds: bookings.map((b) => b.id), paymentMethod: method }, session);
      }
      onDone();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section>
      <Header
        title="Complete payment"
        subtitle={bookings.length === 1 ? `Booking #${bookings[0].id}` : `${bookings.length} bookings · Total ₹${total.toFixed(2)}`}
      />
      <div className="editor compact">
        {groupRef && bookings.length > 1 && (
          <div className="group-reference-banner">
            All {bookings.length} seats in this checkout are tied to booking group <span className="mono">{groupRef}</span>.
          </div>
        )}
        <div className="price-breakdown">
          <h4>Itemized total{bookings.length > 1 ? " (all seats)" : ""}</h4>
          <ul className="price-breakdown-lines">
            {bookings.map((b) => (
              <li key={b.id} className="price-breakdown-subline">
                <span>Seat booking {b.bookingReference} &middot; base ₹{Number(b.baseFare).toFixed(2)} + surcharge ₹{Number(b.seatSurcharge).toFixed(2)} + GST ₹{Number(b.gstAmount).toFixed(2)}</span>
                <span className="mono">₹{Number(b.totalAmount).toFixed(2)}</span>
              </li>
            ))}
          </ul>
          <div className="price-breakdown-total">
            <span>Total due</span>
            <span className="mono">₹{total.toFixed(2)}</span>
          </div>
        </div>
        <Field
          label="Payment method"
          name="paymentMethod"
          value={method}
          onChange={setMethod}
          options={["UPI", "CREDIT_CARD", "DEBIT_CARD", "NET_BANKING", "WALLET"]}
        />
        {error && <div className="error">{error}</div>}
        <div className="form-actions">
          <button className="primary" disabled={busy} onClick={confirm}>
            {busy ? "Processing..." : `Confirm payment${bookings.length > 1 ? ` (₹${total.toFixed(2)})` : ""}`}
          </button>
          <button type="button" className="secondary" onClick={onDone}>Cancel</button>
        </div>
      </div>
    </section>
  );
}

function PaymentHistory({ session }) {
  const [rows, setRows] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    api.get("/payments/history", session).then((data) => setRows(rowsOf(data))).catch((err) => setError(err.message));
  }, []);

  return (
    <section>
      <Header title="Payment History" subtitle="All payments made against your bookings." />
      {error && <div className="error">{error}</div>}
      <DataTable rows={rows} />
    </section>
  );
}

function Tickets({ session }) {
  const isAdmin = session.role === "ADMIN";
  const [rows, setRows] = useState([]);
  const [bookingsById, setBookingsById] = useState({});
  const [schedulesById, setSchedulesById] = useState({});
  const [passengersByBookingId, setPassengersByBookingId] = useState({});
  const [seatsByScheduleId, setSeatsByScheduleId] = useState({});
  const [error, setError] = useState("");

  // TicketResponseDto only carries {id, ticketNumber, bookingId, ticketStatus,
  // issueDate} — nothing about route, passenger, or seat. Assemble those by
  // joining in Booking (scheduleId, seatId) and Schedule (which conveniently
  // already denormalizes source/destination/flightNumber, so no separate
  // /flights call is needed). Passenger and seat details come from
  // role-appropriate endpoints (GET /seats/{id} is admin-only, so seat
  // number is read via /seats/availability/{scheduleId} instead, which any
  // authenticated user can call), fetched once per distinct booking/schedule
  // referenced by these tickets rather than once per ticket.
  const load = async () => {
    setError("");
    try {
      const [ticketData, bookingData, scheduleData] = await Promise.all([
        api.get("/tickets", session),
        api.get("/bookings", session),
        api.get("/schedules", session),
      ]);
      const ticketRows = rowsOf(ticketData);
      const bookingRows = rowsOf(bookingData);
      const scheduleRows = rowsOf(scheduleData);
      const nextBookingsById = Object.fromEntries(bookingRows.map((b) => [b.id, b]));
      const nextSchedulesById = Object.fromEntries(scheduleRows.map((s) => [s.id, s]));

      const bookingIds = [...new Set(ticketRows.map((t) => t.bookingId).filter((id) => id != null))];
      const scheduleIds = [...new Set(bookingIds.map((id) => nextBookingsById[id]?.scheduleId).filter((id) => id != null))];

      const [passengerLists, seatLists] = await Promise.all([
        Promise.all(bookingIds.map((id) => api.get(`/passengers/booking/${id}`, session).then(rowsOf).catch(() => []))),
        Promise.all(scheduleIds.map((id) => api.get(`/seats/availability/${id}`, session).then(rowsOf).catch(() => []))),
      ]);

      setRows(ticketRows);
      setBookingsById(nextBookingsById);
      setSchedulesById(nextSchedulesById);
      setPassengersByBookingId(Object.fromEntries(bookingIds.map((id, i) => [id, passengerLists[i]])));
      setSeatsByScheduleId(Object.fromEntries(scheduleIds.map((id, i) => [id, seatLists[i]])));
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
  }, []);

  // Admin path: DELETE /tickets/{id} (admin-only cancelTicket).
  const removeAsAdmin = async (ticket) => {
    if (!window.confirm(`Cancel ticket ${ticket.ticketNumber}?`)) return;
    setError("");
    try {
      await api.delete(`/tickets/${ticket.id}`, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  // User path: tickets aren't user-cancellable directly (that endpoint is
  // admin-only) — cancelling the underlying booking is what a user can do,
  // and it's the same real-world action ("cancel my ticket").
  const cancelAsUser = async (ticket) => {
    if (!window.confirm("Cancel this booking? This can't be undone.")) return;
    setError("");
    try {
      await api.patch(`/bookings/${ticket.bookingId}/cancel`, {}, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const download = async (row) => {
    setError("");
    try {
      const response = await fetch(`${import.meta.env.VITE_API_BASE_URL || "http://localhost:8080/api"}/tickets/${row.id}/download`, {
        headers: {
          Authorization: `${session.tokenType || "Bearer"} ${session.token}`,
        },
      });
      if (!response.ok) throw new Error("Could not download ticket");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `ticket-${row.ticketNumber || row.id}.pdf`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <Header title="Tickets" subtitle={isAdmin ? "All tickets issued across bookings." : "View and download your tickets."} />
      {error && <div className="error">{error}</div>}
      {!rows.length && <div className="empty">No tickets found.</div>}
      <div className="boarding-pass-grid">
        {rows.map((row) => {
          const booking = bookingsById[row.bookingId];
          const schedule = booking ? schedulesById[booking.scheduleId] : null;
          const passengers = passengersByBookingId[row.bookingId] || [];
          const seat = booking && schedule
            ? (seatsByScheduleId[schedule.id] || []).find((s) => s.seatId === booking.seatId)
            : null;
          return (
            <TicketCard
              key={row.id}
              ticket={row}
              booking={booking}
              schedule={schedule}
              passenger={passengers[0]}
              seat={seat}
              onDownload={() => download(row)}
              onCancel={isAdmin ? () => removeAsAdmin(row) : () => cancelAsUser(row)}
            />
          );
        })}
      </div>
    </section>
  );
}

function TicketCard({ ticket, booking, schedule, passenger, seat, onDownload, onCancel }) {
  const passengerName = passenger ? [passenger.firstName, passenger.lastName].filter(Boolean).join(" ") : null;
  const status = ticket.ticketStatus || booking?.bookingStatus;

  return (
    <article className="boarding-pass">
      <div className="boarding-pass-main">
        <div className="boarding-pass-row boarding-pass-route">
          <div>
            <span className="boarding-pass-label">From</span>
            <strong className="mono">{schedule?.source || "—"}</strong>
          </div>
          <Plane size={18} className="boarding-pass-plane" />
          <div>
            <span className="boarding-pass-label">To</span>
            <strong className="mono">{schedule?.destination || "—"}</strong>
          </div>
        </div>
        <div className="boarding-pass-row boarding-pass-details">
          <div>
            <span className="boarding-pass-label">Passenger</span>
            <strong>{passengerName || "—"}</strong>
          </div>
          <div>
            <span className="boarding-pass-label">Travel date</span>
            <strong className="mono">
              {schedule?.departureDate || "—"}{schedule?.departureTime ? ` · ${schedule.departureTime}` : ""}
            </strong>
          </div>
        </div>
        <div className="boarding-pass-row boarding-pass-details">
          <div>
            <span className="boarding-pass-label">Flight</span>
            <strong className="mono">{schedule?.flightNumber || "—"}</strong>
          </div>
          <div>
            <span className="boarding-pass-label">Seat</span>
            <strong className="mono">{seat?.seatNumber || "—"}</strong>
          </div>
        </div>
      </div>
      <div className="boarding-pass-stub">
        <span className="boarding-pass-label">Ticket</span>
        <strong className="mono">{ticket.ticketNumber || ticket.id}</strong>
        {status && <span className={`status-pill status-${String(status).toLowerCase()}`}>{status}</span>}
        <div className="boarding-pass-actions">
          {onDownload && (
            <button type="button" className="secondary icon-text" onClick={onDownload}>
              <Download size={14} /> PDF
            </button>
          )}
          {onCancel && status !== "CANCELLED" && (
            <button type="button" className="secondary" onClick={onCancel}>
              Cancel
            </button>
          )}
        </div>
      </div>
    </article>
  );
}

// USER-only: edit their own profile. Assumes GET/PUT /users/{id} is allowed
// for the owning user (not just admins).
function Profile({ session }) {
  const [form, setForm] = useState({ firstName: "", lastName: "", email: "", phoneNumber: "" });
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  const [saved, setSaved] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});

  useEffect(() => {
    api.get(`/users/${session.userId}`, session)
      .then((data) => {
        setForm({
          firstName: data.firstName || "",
          lastName: data.lastName || "",
          email: data.email || "",
          phoneNumber: data.phoneNumber || "",
        });
        setLoaded(true);
      })
      .catch((err) => setError(err.message));
  }, []);

  const profileFields = [
    { name: "firstName", label: "First name" },
    { name: "lastName", label: "Last name" },
    { name: "email", label: "Email" },
    { name: "phoneNumber", label: "Phone number" },
  ];

  const save = async (event) => {
    event.preventDefault();
    setError("");
    setSaved(false);
    const errors = validateRequired(form, profileFields);
    setFieldErrors(errors);
    if (Object.keys(errors).length) return;
    try {
      await api.put(`/users/${session.userId}`, form, session);
      setSaved(true);
    } catch (err) {
      setError(err.message);
    }
  };

  const fieldProps = (name) => ({
    error: fieldErrors[name],
    onChange: (value) => {
      setForm({ ...form, [name]: value });
      if (fieldErrors[name]) setFieldErrors({ ...fieldErrors, [name]: undefined });
    },
  });

  return (
    <section>
      <Header title="My Profile" subtitle="Update your personal details." />
      {!loaded ? (
        <div className="empty">Loading...</div>
      ) : (
        <form className="editor" onSubmit={save}>
          <Field label="First name" value={form.firstName} {...fieldProps("firstName")} />
          <Field label="Last name" value={form.lastName} {...fieldProps("lastName")} />
          <Field label="Email" type="email" value={form.email} {...fieldProps("email")} />
          <Field label="Phone number" value={form.phoneNumber} {...fieldProps("phoneNumber")} />
          {error && <div className="error">{error}</div>}
          {saved && <div className="success">Profile updated.</div>}
          <div className="form-actions">
            <button className="primary">Save changes</button>
          </div>
        </form>
      )}
    </section>
  );
}

function SimpleCreateList({ title, subtitle, resource, empty, fields, session, deletable = false, dedupeBy }) {
  const [rows, setRows] = useState([]);
  const [form, setForm] = useState(empty);
  const [error, setError] = useState("");

  const load = async () => {
    setError("");
    try {
      setRows(rowsOf(await api.get(`/${resource}`, session)));
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    load();
  }, [resource]);

  const create = async (event) => {
    event.preventDefault();
    try {
      await api.post(`/${resource}`, normalizePayload(form, fields), session);
      setForm(empty);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (row) => {
    try {
      await api.delete(`/${resource}/${row.id || row.passengerId}`, session);
      await load();
    } catch (err) {
      setError(err.message);
    }
  };

  // Display-only: the same person can end up with multiple passenger rows
  // (one per booking they've been added to), so show only the first row per
  // distinct passport number. Create/edit/delete still operate on the real,
  // un-deduped records underneath — this doesn't change what's stored or
  // how those actions work, only what's listed.
  const displayRows = useMemo(() => {
    if (!dedupeBy) return rows;
    const seen = new Set();
    return rows.filter((row) => {
      const key = row[dedupeBy];
      if (key == null || key === "") return true;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }, [rows, dedupeBy]);

  return (
    <section>
      <Header title={title} subtitle={subtitle || "Connected directly to the matching backend endpoint."} />
      {session.role === "USER" && (
        <form className="editor compact" onSubmit={create}>
          {fields.map((field) => (
            <Field key={field.name} {...field} value={form[field.name] ?? ""} onChange={(value) => setForm({ ...form, [field.name]: value })} />
          ))}
          <button className="primary">Create</button>
        </form>
      )}
      {error && <div className="error">{error}</div>}
      <DataTable rows={displayRows} onDelete={deletable ? remove : undefined} />
    </section>
  );
}

// createdAt/updatedAt exist on every entity for auditing but aren't useful
// to show in any admin/user table — hiding them here (rather than per-usage)
// means every DataTable in the app is fixed by this one change.
const HIDDEN_COLUMNS = new Set(["createdAt", "updatedAt"]);

function DataTable({ rows, onEdit, onDelete, extraActions }) {
  const columns = useMemo(
    () => Array.from(new Set(rows.flatMap((row) => Object.keys(row || {})))).filter((c) => !HIDDEN_COLUMNS.has(c)).slice(0, 10),
    [rows]
  );
  if (!rows.length) return <div className="empty">No records found.</div>;
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {columns.map((column) => <th key={column}>{column}</th>)}
            {(onEdit || onDelete || extraActions) && <th>actions</th>}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, index) => (
            <tr key={row.id || row.passengerId || row.ticketNumber || index}>
              {columns.map((column) => <td key={column}>{format(row[column])}</td>)}
              {(onEdit || onDelete || extraActions) && (
                <td className="row-actions">
                  {onEdit && <button onClick={() => onEdit(row)}>Edit</button>}
                  {onDelete && <button onClick={() => onDelete(row)}>Delete</button>}
                  {extraActions?.(row)}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Header({ title, subtitle }) {
  return (
    <header className="page-header">
      <h1>{title}</h1>
      <p>{subtitle}</p>
    </header>
  );
}

function Field({ label, name, value, onChange, type = "text", options, error }) {
  const id = name || label.toLowerCase().replaceAll(" ", "-");
  return (
    <label className={`field${error ? " field-invalid" : ""}`} htmlFor={id}>
      <span>{label}</span>
      {options ? (
        <select id={id} value={value} onChange={(event) => onChange(event.target.value)} aria-invalid={!!error}>
          <option value="">Select...</option>
          {options.map((option) => {
            if (typeof option === "string") {
              return <option key={option} value={option}>{option}</option>;
            }
            return <option key={option.value} value={option.value}>{option.label}</option>;
          })}
        </select>
      ) : (
        <input id={id} type={type} value={value} onChange={(event) => onChange(event.target.value)} aria-invalid={!!error} />
      )}
      {error && <span className="field-error">{error}</span>}
    </label>
  );
}

const flightFields = [
  { name: "flightNumber", label: "Flight number" },
  { name: "airlineName", label: "Airline name" },
  { name: "source", label: "Source" },
  { name: "destination", label: "Destination" },
  { name: "price", label: "Price", type: "number" },
  { name: "status", label: "Status", options: ["SCHEDULED", "DELAYED", "CANCELLED", "DEPARTED"] },
  { name: "aircraftId", label: "Aircraft" },
];
const aircraftFields = [{ name: "modelNo", label: "Model number" }, { name: "totalSeats", label: "Total seats", type: "number" }];
const scheduleFields = [
  { name: "departureDate", label: "Departure date", type: "date" },
  { name: "departureTime", label: "Departure time", type: "time" },
  { name: "arrivalTime", label: "Arrival time", type: "time" },
  { name: "flightId", label: "Flight" },
];
const seatFields = [
  { name: "seatNumber", label: "Seat number" },
  { name: "seatClass", label: "Seat class", options: ["ECONOMY", "PREMIUM_ECONOMY", "BUSINESS", "FIRST"] },
  { name: "seatType", label: "Seat type", options: ["WINDOW", "AISLE", "MIDDLE"] },
  { name: "aircraftId", label: "Aircraft ID", type: "number" },
];
const bookingFields = [{ name: "userId", label: "User ID", type: "number" }, { name: "scheduleId", label: "Schedule ID", type: "number" }, { name: "seatId", label: "Seat ID", type: "number" }];
const emptyPassenger = { firstName: "", lastName: "", gender: "MALE", dateOfBirth: "", passportNumber: "", nationality: "", bookingId: "" };
const passengerFields = [
  { name: "firstName", label: "First name" },
  { name: "lastName", label: "Last name" },
  { name: "gender", label: "Gender", options: ["MALE", "FEMALE", "OTHER"] },
  { name: "dateOfBirth", label: "Date of birth", type: "date" },
  { name: "passportNumber", label: "Passport number" },
  { name: "nationality", label: "Nationality" },
  { name: "bookingId", label: "Booking ID", type: "number" },
];

function iconFor(tab) {
  const props = { size: 18 };
  return {
    dashboard: <Shield {...props} />,
    search: <Search {...props} />,
    flights: <Plane {...props} />,
    aircraft: <Plane {...props} />,
    schedules: <CalendarClock {...props} />,
    seats: <Armchair {...props} />,
    users: <Users {...props} />,
    bookings: <Ticket {...props} />,
    passengers: <User {...props} />,
    history: <History {...props} />,
    tickets: <Ticket {...props} />,
    profile: <UserCog {...props} />,
  }[tab];
}

function labelFor(tab) {
  const overrides = { history: "Payment history" };
  return overrides[tab] || (tab[0].toUpperCase() + tab.slice(1));
}

function rowsOf(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.content)) return data.content;
  return data ? [data] : [];
}

function normalizePayload(form, fields) {
  return Object.fromEntries(fields.map((field) => {
    const value = form[field.name];
    return [field.name, field.type === "number" && value !== "" ? Number(value) : value];
  }));
}

function clean(object) {
  return Object.fromEntries(Object.entries(object).filter(([, value]) => value !== ""));
}

function pick(object, keys) {
  return Object.fromEntries(keys.map((key) => [key, object[key]]));
}

function format(value) {
  if (value === null || value === undefined) return "";
  if (typeof value === "object") return JSON.stringify(value);
  return String(value);
}

createRoot(document.getElementById("root")).render(<App />);